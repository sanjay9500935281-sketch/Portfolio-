# Sanjay B — Professional Portfolio

A responsive, static portfolio website built with HTML, CSS, and JavaScript using details from the supplied resume.

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in any modern browser.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `script.js`, and this README to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish your website.

## Personal details to review
- Verify the phone number, email address, LinkedIn profile, and GitHub profile before publishing publicly.
- Add real project/demo links if available. Project descriptions are based on the resume information provided.
- This is a static portfolio; it does not include a backend or store contact-form submissions.

## Files
- `index.html` — portfolio content and page structure
- `styles.css` — layout, responsive design, and visual styling
- `script.js` — mobile navigation and current year
